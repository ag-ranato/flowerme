import SwiftUI

struct GoogleSignInButtonView: View {
    var body: some View {
        Button(action: {
            GoogleSignInManager.shared.signIn()
        }) {
            HStack {
                Image(systemName: "globe") // 나중에 구글 로고 이미지로 변경 가능
                Text("구글로 로그인")
                    .font(.headline)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.red)
            .foregroundColor(.white)
            .cornerRadius(8)
        }
        .padding()
    }
}

